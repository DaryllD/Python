# python_july_2017

Setup

Fork this repo to your github account.
Clone it locally onto your laptop.
Create a folder with your name, ex: cody_williams
Add this (https://github.com/CodingDojoDallas/python_july_2017/) repo as a REMOTE to your locally cloned copy.
Profit!
Daily Commits

Please commit daily. That way we can provide you with feedback :) or just a thumbs up if everything looks good. Here is a good resource that describes how daily commit process should go.

https://codingdojo-dallas.slack.com/files/katemoc/F427ZQZPY/github_workflow_v4.pdf
